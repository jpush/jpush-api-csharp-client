﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

using cn.jpush.api;
using cn.jpush.api.push;
using cn.jpush.api.report;
using cn.jpush.api.common;
using cn.jpush.api.util;

namespace JpushApiClientExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("************");
            Console.WriteLine("*****开始发送******");

            //String result;
            String master_secret = "2b38ce69b1de2a7fa95706ea";
            String app_key = "dd1066407b044738b6479275";
            int sendno = 9;
            JPushClient client = new JPushClient(app_key, master_secret);
            MessageResult result = null;


            //send notify message
            Console.WriteLine("*****发送通知******");
            result = client.sendNotificationAll("notify content");
            Console.WriteLine("sendNotificationAll:**返回状态：" + result.getErrorCode().ToString() +
                          "  **返回信息:" + result.getErrorMessage() +
                          "  **Send No.:" + result.getSendNo() +
                          "  msg_id:" + result.getMessageId() +
                          "  频率次数：" + result.getRateLimitQuota() +
                          "  可用频率：" + result.getRateLimitRemaining() +
                          "  重置时间：" + result.getRateLimitReset());

            Console.WriteLine("*****发送消息******");
            result = client.sendCustomMessageAll("custom all","notify content");
            Console.WriteLine("sendCustomMessageAll:**返回状态：" + result.getErrorCode().ToString() +
                          "  **返回信息:" + result.getErrorMessage() +
                          "  **Send No.:" + result.getSendNo() +
                          "  msg_id:" + result.getMessageId() +
                          "  频率次数：" + result.getRateLimitQuota() +
                          "  可用频率：" + result.getRateLimitRemaining() +
                          "  重置时间：" + result.getRateLimitReset());


            NotificationParams notifyParams = new NotificationParams();
            CustomMessageParams customParams = new CustomMessageParams();

            //notifyParams.
            Dictionary<String, Object> extras = null;


            Console.WriteLine("*****发送带tag通知******");

            notifyParams.addPlatform(DeviceEnum.Android);
            notifyParams.ReceiverType = ReceiverTypeEnum.TAG;
            notifyParams.ReceiverValue = "tag_api";
            notifyParams.SendNo = 256;
            //notifyParams.OverrideMsgId = "1";

            result = client.sendNotification("tag notify content", notifyParams, extras);
            Console.WriteLine("sendNotificationAll:**返回状态：" + result.getErrorCode().ToString() +
                          "  **返回信息:" + result.getErrorMessage() +
                          "  **Send No.:" + result.getSendNo() +
                          "  msg_id:" + result.getMessageId() +
                          "  频率次数：" + result.getRateLimitQuota() +
                          "  可用频率：" + result.getRateLimitRemaining() +
                          "  重置时间：" + result.getRateLimitReset());



            Console.WriteLine("*****发送带tag消息******");
            customParams.addPlatform(DeviceEnum.Android);
            customParams.ReceiverType = ReceiverTypeEnum.TAG;
            customParams.ReceiverValue = "tag_api";
            customParams.SendNo = 256;
            result = client.sendCustomMessage("send custom mess", "tag notify content", customParams, extras);
            Console.WriteLine("sendCustomMessage:**返回状态：" + result.getErrorCode().ToString() +
                          "  **返回信息:" + result.getErrorMessage() +
                          "  **Send No.:" + result.getSendNo() +
                          "  msg_id:" + result.getMessageId() +
                          "  频率次数：" + result.getRateLimitQuota() +
                          "  可用频率：" + result.getRateLimitRemaining() +
                          "  重置时间：" + result.getRateLimitReset());


            extras = new Dictionary<String, Object>();
            //Dictionary<String, Object> innerExtras = new Dictionary<String, Object>();   
           // innerExtras.Add("badge",88);
           // innerExtras.Add("sound","happy");
           // String innerString = JsonTool.DictionaryToJson(innerExtras);
            //IOSExtras innerExtras = new IOSExtras();
            // extras.Add("ios", innerExtras);
          //  Console.WriteLine("*****发送带tag通知******" + innerString);
          //  extras.Add("ios", innerString);
          //  extras.Add("user_param_1", "cc");
          //  extras.Add("user_param_2", "dddd");


            Console.WriteLine("*****发送带alias通知******");

            notifyParams.addPlatform(DeviceEnum.Android);
            notifyParams.ReceiverType = ReceiverTypeEnum.ALIAS;
            notifyParams.ReceiverValue = "alias_api";
            notifyParams.SendNo = 257;
            //notifyParams.OverrideMsgId = "2";

            result = client.sendNotification("alias notify content", notifyParams, extras);
            Console.WriteLine("sendNotificationAll:**返回状态：" + result.getErrorCode().ToString() +
                          "  **返回信息:" + result.getErrorMessage() +
                          "  **Send No.:" + result.getSendNo() +
                          "  msg_id:" + result.getMessageId() +
                          "  频率次数：" + result.getRateLimitQuota() +
                          "  可用频率：" + result.getRateLimitRemaining() +
                          "  重置时间：" + result.getRateLimitReset());


            Console.WriteLine("*****发送带tag消息******");
            customParams.addPlatform(DeviceEnum.Android);
            customParams.ReceiverType = ReceiverTypeEnum.ALIAS;
            customParams.ReceiverValue = "alias_api";
            customParams.SendNo = 256;
            result = client.sendCustomMessage("send custom mess", "alias notify content", customParams, extras);
            Console.WriteLine("sendCustomMessage:**返回状态：" + result.getErrorCode().ToString() +
                          "  **返回信息:" + result.getErrorMessage() +
                          "  **Send No.:" + result.getSendNo() +
                          "  msg_id:" + result.getMessageId() +
                          "  频率次数：" + result.getRateLimitQuota() +
                          "  可用频率：" + result.getRateLimitRemaining() +
                          "  重置时间：" + result.getRateLimitReset());


            


            //send custom message
            //result = client.sendCustomMessageAll("custom title", "custom notify content");


            Console.WriteLine();

            String msg_ids = "1613113584,1229760629,1174658841,1174658641";
              ReceivedResult receivedResult = client.getReceivedApi(msg_ids);

              Console.WriteLine("Report Result:");
            foreach(ReceivedResult.Received re in receivedResult.ReceivedList)
            {
                Console.WriteLine("getReceivedApi************msgid=" + re.msg_id+ "  ***andriod received="+re.android_received+" ***ios received="+re.ios_apns_sent);            
            }
            Console.WriteLine();
        }
    
        public class IOSExtras
        {
            public int badge = 888;
            public String sound = "happy";
        }
    }
}
