﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using cn.jpush.api;

namespace JpushApiClientExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("************");
            Console.WriteLine();

            String result;
            String master_secret = "2b38ce69b1de2a7fa95706ea";
            String app_key = "dd1066407b044738b6479275";
            int sendno = 9;
            JPushClient client = new JPushClient(app_key, master_secret, 0);
            result = client.sendNotificationByTag("tag_api", sendno, "des", "tag notify title", "tag notify content", "android", "", "");

            Console.Write("sendNotificationByTag************" + result);
            Console.WriteLine();

            

              //
              sendno++;
              result = client.sendCustomMesByTag("tag_api", sendno, "des", "tag notify title", "tag notify content", "android", "", "");

             Console.Write("sendCustomMesByTag************" + result);
            Console.WriteLine();
            
              //
              sendno++;
              result = client.sendNotificationByAlias("alias_api", sendno, "des", "tag notify title", "tag notify content", "android", "", "");

             Console.Write("sendNotificationByAlias************" + result);
            Console.WriteLine();
            
              //
              sendno++;
              result = client.sendCustomMesByAlias("alias_api", sendno, "des", "tag notify title", "tag notify content", "android", "", "");

             Console.Write("sendCustomMesByAlias************" + result);
            Console.WriteLine();
              //
              //
              sendno++;
             result = client.sendNotificationByAppkey(sendno, "des", "tag notify title", "tag notify content", "android", "", "");

            Console.Write("sendNotificationByTag************" + result);
            Console.WriteLine();
              //
              //
              sendno++;
             result = client.sendCustomMesByAppkey(sendno, "des", "tag notify title", "tag notify content", "android", "", "");

            Console.Write("sendNotificationByTag************" + result);
            Console.WriteLine();

              String msg_ids="929123086,1197558554";
             result = client.getReceivedApi(msg_ids);

             Console.Write("getReceivedApi************" + result);
            Console.WriteLine();
        }
    
    }
}
